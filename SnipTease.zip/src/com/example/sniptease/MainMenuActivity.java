/**@author David Westgate
 * SnipTease LLC.
 * 17 April 2014
 * */
package com.example.sniptease;

import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.SearchView;
import android.widget.SearchView.OnCloseListener;

public class MainMenuActivity extends Activity implements
		NewsFragment.OnFragmentInteractionListener,
		ProfileFragment.OnFragmentInteractionListener,
		FollowersFragment.OnFragmentInteractionListener,
		ChatFragment.OnFragmentInteractionListener {
	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_news, container,
					false);
			return rootView;
		}
	}

	/**
	 * The serialization (saved instance state) Bundle key representing the
	 * current tab position.
	 */
	public void editProfileButton(View v) {
		Intent intent = new Intent(this, EditProfileActivity.class);
		startActivity(intent);
	}

	private static final String STATE_SELECTED_NAVIGATION_ITEM = "selected_navigation_item";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_ACTION_BAR_OVERLAY);
		setContentView(R.layout.activity_main_menu);

		getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

		Tab mNewsTab = getActionBar().newTab().setText("News Feed");
		Tab mProfileTab = getActionBar().newTab().setText("Profile");
		Tab mFollowersTab = getActionBar().newTab().setText("Followers");
		Tab mChatTab = getActionBar().newTab().setText("Chat");

		Fragment mNewsFragment = new NewsFragment();
		Fragment mProfileFragment = new ProfileFragment();
		Fragment mFollowersFragment = new FollowersFragment();
		Fragment mChatFragment = new ChatFragment();

		mNewsTab.setTabListener(new MyTabsListener(mNewsFragment,
				getApplicationContext()));
		mProfileTab.setTabListener(new MyTabsListener(mProfileFragment,
				getApplicationContext()));
		mFollowersTab.setTabListener(new MyTabsListener(mFollowersFragment,
				getApplicationContext()));
		mChatTab.setTabListener(new MyTabsListener(mChatFragment,
				getApplicationContext()));

		getActionBar().addTab(mNewsTab);
		getActionBar().addTab(mProfileTab);
		getActionBar().addTab(mFollowersTab);
		getActionBar().addTab(mChatTab);

		getActionBar().show();
	}
	SearchView searchView;
	Menu thisMenu;
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main_menu, menu);
		final MenuItem searchMenuItem = menu.findItem(R.id.search_bar_friends);
		searchView = (SearchView) searchMenuItem
                .getActionView();
		
		searchView.setIconifiedByDefault(true);

		
		thisMenu = menu;
		searchView.setOnCloseListener(new OnCloseListener(){

			@Override
			public boolean onClose() {
				
	
				thisMenu.setGroupVisible(R.id.search_bar_group, false);
				thisMenu.setGroupEnabled(R.id.search_bar_group, false);
				thisMenu.setGroupVisible(R.id.default_main_group, true);
				thisMenu.setGroupEnabled(R.id.default_main_group, true);
				return false;
			}
		});
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public void onFragmentInteraction(Uri uri) {
		// TODO Auto-generated method stub
	}
	public void addFriendsButton(View V){
		

		thisMenu.setGroupVisible(R.id.default_main_group, false);
		thisMenu.setGroupEnabled(R.id.default_main_group, false);
		searchView.setIconified(false);
		thisMenu.setGroupVisible(R.id.search_bar_group, true);
		thisMenu.setGroupEnabled(R.id.search_bar_group, true);
		
		
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_camera) {
			startActivity(new Intent(MainMenuActivity.this,
					CameraActivity.class));
			return true;
		}
		 else if(id == R.id.action_logout) {
			 finish();
			 return true;
		 }
		else if (id == R.id.action_settings) {
			Intent intent = new Intent(MainMenuActivity.this,
					SettingsActivity.class);

			startActivity(intent);
			return true;
		}

		else {
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public void onRestoreInstanceState(Bundle savedInstanceState) {
		// Restore the previously serialized current tab position.
		if (savedInstanceState.containsKey(STATE_SELECTED_NAVIGATION_ITEM)) {
			getActionBar().setSelectedNavigationItem(
					savedInstanceState.getInt(STATE_SELECTED_NAVIGATION_ITEM));
		}
	}
}
